﻿#include "Sample.h"

class TSampleImpl : public ISample {
public:
  TSampleImpl(int id) : m_id(id) {}
  ~TSampleImpl() override = default;

  // ISample overrides:
  int Id() const override { return m_id; }

private:
  const int m_id;
};

class TSamplesImpl : public ISamples,
                     public tStdPtrList<TSampleImpl, ISample> {
public:
  TSamplesImpl() = default;
  ~TSamplesImpl() override = default;

  // ISamples overrides:
  ISample* Add(int id) override {
	Ptr<TSampleImpl> newSample(new TSampleImpl(id));
	m_samples.push_back(newSample);
	return newSample;
  }

private:
  // tStdPtrList overrides:
  const StdList& getStdListRefConst() const override { return m_samples; }
  StdList& getStdListRef() override { return m_samples; }

  std::list<Ptr<TSampleImpl>> m_samples;
};

Ptr<ISamples> CreateSamples() {
  return new TSamplesImpl();
}
