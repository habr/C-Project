﻿#include "ILS/list.hpp"

class ISample : virtual public Root {
public:
	virtual int Id() const = 0;
};

class ISamples : virtual public tIPtrList<ISample> {
public:
  virtual ISample* Add(int id) = 0;
};

Ptr<ISamples> CreateSamples();
