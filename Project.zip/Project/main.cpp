﻿#include <cstdlib>
#include <iostream>

#include "ILS/ptr.hpp"
#include "Sample.h"

int main() {
  atexit(&Root::DetectLeaks);

  Ptr<ISamples> samples = CreateSamples();
  samples->Add(22);
  samples->Add(333);
  samples->Add(1);
  samples->Add(9);

  std::cout << "Number of samples: " << samples->size() << '\n'
            << "First sample id: " << samples->front()->Id() << '\n'
            << "Last sample id: " << samples->back()->Id() << '\n';
  auto it = samples->begin();
  std::cout << "All samples: [" << (*it)->Id();
  for (++it; it != samples->end(); ++it) {
    std::cout << ", " << (*it)->Id();
  }
  std::cout << "]\n";
  return 0;
}
