﻿
/// \file qualificator.hpp
/// Определение интерфейсов квалификации объектов. 
/// @ingroup IKernel
/// Определение базовых интерфейсов \c DAPL::tIQualified и \c DAPL::tIQualificator и сопутсвующих для работы с фиксированным набором именнованных однотипных параметров.

#ifndef DAPL_IKERNEL_QUALIFICATOR_HPP
#define DAPL_IKERNEL_QUALIFICATOR_HPP

#include "types.hpp"

//=============================================================================
/// Интерфейс квалифицируемого объекта.
/// @ingroup IKernel
/// Этот шаблон определяет интерфейс объекта, который может быть квалифицирован 
/// одним числом (или объектом) типа QTYPE. В данном контексте под квалификацией понимается
/// просто присвоение данному объекту некоторого числа - квалификатора.
/// В дальнейшем в можно лекго сортировать такие объекты в списке по убыванию или возрастанию 
/// квалификатора. Именно для сортировки данный итрейфейс и вводится.
/// \param QTYPE - тип квалификационного значения.
/// \note По умолчанию этот интерфейс имеет некоторую тривиальную реализацию. 
/// То есть фактически данный класс не является интерфейсом в обычном смысле этого слова, 
/// он реализует некоторую стандартную функциональность квалификации объекта. Однако, 
/// идеалогически этот класс является интерфейсом, и поэтому оформлен как интерфейс, 
/// он просто реализует механизм квалификации, чтобы его не надо было повторять в каждом классе,
/// поддерживающим этот интрефейс.
///
/// \see tQualifyComparator , tIQualificator , IQualified 
template<class QTYPE> struct tIQualified : virtual public Root {
	typedef QTYPE QualifyType;   // Тип квалификационного значния для данного квалифицируемого объекта.
private:
	mutable QTYPE qualify_value; // Значение квалификации объекта (квалификационное значение).
	mutable ULong num_qualified; // Количество раз, сколько была проделана квалификация объекта. При этом qualify_value содержит среднее значение всех квалификаций.
protected: // конструктор умолчания делаем защищенным, чтобы этот класс не создавался явно.
	tIQualified() : qualify_value(), num_qualified(0) {}
public: 
#ifdef _DEBUG
	mutable std::string dbg_qfunc;
#endif //#ifdef _DEBUG

	/// Текущее значение квалификатора.
	/// Функция возвращает текущее значение кфалификатора, или умолчательное
	/// значение типа квалификатора если объект еще не был квалифицирован.
	virtual QTYPE getQualifyValue() const {
		return qualify_value;
	}
	/// Установить значение квалификатора.
	/// Функция устанавливает значение квалификатора, его старое значение проподает.
	virtual void setQualifyValue(const QTYPE& q) const {
		if(num_qualified==0) qualify_value=q;
		else qualify_value=(qualify_value*num_qualified+q)/(num_qualified+1);
		num_qualified++;
	}
	/// Обнуление квалификатора.
	/// Функция стирает текущее значение квалификатора и сброс флага о том, что объект был квалифицирован.
	virtual void releaseQualifyValue() const {qualify_value=QTYPE();num_qualified=0;}
	/// Обнуление квалификатора.
	/// Функция стирает текущее значение квалификатора и сброс флага о том, что объект был квалифицирован.
	virtual bool wasQualified() const {return num_qualified>0;}

public: 
	/// Явное значение квалификации.
	/// Функция возвращает значение квалификации вне зависимости от того, были ли квалифицирован объект или нет.
	/// Функция используется для сохранения или считывания значений. 
	virtual QTYPE getQualifyVal() const {
		return qualify_value;
	}
	/// Явное значение количества квалификаций.
	/// Функция возвращает количество квалификаций вне зависимости от того, были ли квалифицирован объект или нет.
	/// Функция используется для сохранения или считывания количества квалификаций.
	virtual ULong getQualifyNum() const {
		return num_qualified;
	}
	/// Явная установка значения квалификации.
	/// Функция устанавливает значение квалификации вне зависимости от того, были ли квалифицирован объект или нет.
	/// Функция используется для сохранения или считывания значений. 
	virtual void setQualifyVal(const QTYPE& val) const {
		qualify_value = val;
	}
	/// Явная установка количества квалификаций.
	/// Функция устанавливает  количество квалификаций вне зависимости от того, были ли квалифицирован объект или нет.
	/// Функция используется для сохранения или считывания количества квалификаций.
	virtual void setQualifyNum(const ULong& num) const {
		num_qualified = num;
	}
}; //struct tIQualified

/// Интерфейс объекта, квалифицируемого действительным числом.
/// @ingroup IKernel
/// В подовляющем большинстве случаеd объект квалифицируется (см. \c tIQualified) дейстивтельным числом.
/// Поэтому данная специализация шаблона интрефейса \c tIQualified выделена как основная.
/// \see tIQualified , tQualifyComparator , IQualificator
typedef tIQualified<Real> IQualified;

//=============================================================================
/// Сравниватель квалифицированных объектов.
/// @ingroup IKernel
/// Данный шаблон класса служит для одной цели - сравнить два указателя (или \c Ptr-а) на
/// квалифицированные объекты. Это нужно для сортировки списков квалифицированных объектов.
/// При конструировании объекта по этому шаблону можно указать тип сортировки, который он будет определять.
/// По умолчанию, или если аргумент конструктора равен \c true, будет сортировка по убыванию квалификационного значения,
/// в противном случае - по возрастанию.
///
/// Пример сортировки \c Ptr-ов по убыванию квалификационного значения:
/// \code
///	std::list< Ptr<SomeClass> > list1;
///	...
///	some_qualificator.qualify(list1.begin(),list1.end());
///	list1.sort(tQualifyComparator< Ptr<SomeClass> >());
/// \endcode
///
/// Пример сортировки указателей по возрастанию квалификационного значения:
/// \code
///	std::list< SomeClass* > list2;
///	...
///	some_qualificator.qualify(list2.begin(),list2.end());
///	list2.sort(tQualifyComparator< SomeClass* >(false));
/// \endcode
///
/// \param TYPE - тип элементов списка для сортировки.
/// \see tIQualified , tQualificator
template<class TYPE, class QTYPE=Real> struct tQualifyComparator {
private:
	bool descend_sort; // Тип сортировки, если true - сортировка по убыванию, иначе по возрастанию.
public:
	/// Конструктор умолчания.
	/// Конструктор посваляет определить тип сортировки, который будет определять объект.
	/// \param ds - сортировать по убыванию?
	tQualifyComparator(bool ds=true) : descend_sort(ds) {}
	/// Оператор сравнения.
	/// Оператор "круглые скобки" в данном контексте реализует оаертор сравнения двух объектов.
	bool operator()(const TYPE& aaa, const TYPE& bbb) const {
		const tIQualified<QTYPE>* a = dynamic_cast<const tIQualified<QTYPE>*>(&aaa);
		const tIQualified<QTYPE>* b = dynamic_cast<const tIQualified<QTYPE>*>(&bbb);
		if(descend_sort) return a->getQualifyValue()>b->getQualifyValue();
		else  return a->getQualifyValue()<b->getQualifyValue();
	}
};

template<class TYPE_P, class QTYPE> struct tQualifyComparator< TYPE_P*, QTYPE > {
private:
	bool descend_sort;
public:
	tQualifyComparator(bool ds=true) : descend_sort(ds) {}
	bool operator()(TYPE_P* aaa, TYPE_P* bbb) const {
		tIQualified<QTYPE>* a = dynamic_cast<tIQualified<QTYPE>*>(aaa);
		tIQualified<QTYPE>* b = dynamic_cast<tIQualified<QTYPE>*>(bbb);
		if(descend_sort) return a->getQualifyValue()>b->getQualifyValue();
		else  return a->getQualifyValue()<b->getQualifyValue();
	}
};

template<class TYPE_PTR, class QTYPE> struct tQualifyComparator< Ptr<TYPE_PTR>, QTYPE > {
private:
	bool descend_sort;
public:
	tQualifyComparator(bool ds=true) : descend_sort(ds) {}
	bool operator()(const Ptr<TYPE_PTR>& aaa, const Ptr<TYPE_PTR>& bbb) const {
		tIQualified<QTYPE>* a = dynamic_cast<tIQualified<QTYPE>*>(aaa.get());
		tIQualified<QTYPE>* b = dynamic_cast<tIQualified<QTYPE>*>(bbb.get());
		if(descend_sort) return a->getQualifyValue()>b->getQualifyValue();
		else  return a->getQualifyValue()<b->getQualifyValue();
	}
};

//=============================================================================
/// Интерфейс квалификатора.
/// @ingroup IKernel
/// Этот шаблон определяет интерфейс квалификатора, то есть объекта, который вычисялет и 
/// присваивает квалификационное значение объекту, поддерживающему интерфейс \c tIQualified.
/// \param QTYPE - тип квалификационного значения.
/// \see tIQualified , tQualifyComparator , IQualificator 
template<class QTYPE> struct tIQualificator : virtual public Root {
protected:
	/// Вычисление квалификационного значения.
	/// Функция вычиляет квалификационное значение по переданному указателю на интерфейс \c tIQualified.
	/// \attention Эта функция не меняет квалификационное значение переданного объекта, а только вычисляет его!
	/// \param obj - указатель на объект, который надо квалифицировать.
	/// \return - квалификационное значение этого объекта.
	/// \note Эта функия единственная, которую надо переопределять при реализации интрефейса, 
	/// остальные функции вызывают ее.
	virtual QTYPE qualifyValue(const tIQualified<QTYPE>* obj) const = 0;
public: 
	/// Квалификация объекта по Ptr-у.
	/// Функция квалицицирует объект, переданный в виде Ptr-а.
	template<class OTYPE> void qualify(const Ptr<OTYPE>& p_obj) const {
		tIQualified<QTYPE>* q=dynamic_cast< tIQualified<QTYPE>* >(p_obj.get());
		if(q==NULL) return;
		q->setQualifyValue(qualifyValue(q));
	}
	/// Квалификация объекта по указателю.
	/// Функция квалицицирует объект, переданный в виде указателя.
	void qualify(tIQualified<QTYPE>* p_obj) const {p_obj->setQualifyValue(qualifyValue(p_obj));}
	/// Квалификация объекта по ссылке.
	/// Функция квалицицирует объект, переданный в виде ссылки.
	void qualify(tIQualified<QTYPE>& r_obj) const {r_obj.setQualifyValue(qualifyValue(&r_obj));}
	/// Квалификация писка объектов.
	/// Функция квалицицирует список объектов, переданный в виде начального и конечного итераторов 
	/// по Ptr-ам или указателям на квалифицируемые объекты, либо по самим квалифицируемым объектам.
	template<class ITYPE> void qualify(const ITYPE& start, const ITYPE& finish) const {
		for(ITYPE it=start;it!=finish;++it)
			qualify(*it);
	}
}; //struct tIQualificator

/// Интерфейс кваликатора действительным числом.
/// @ingroup IKernel
/// В подовляющем большинстве случаеd объект квалифицируется (см. \c tIQualified) дейстивтельным числом.
/// Поэтому данная специализация шаблона интрефейса \c IQualificator выделена как основная.
/// \see tIQualificator , tQualifyComparator , IQualified
typedef tIQualificator<Real> IQualificator;

#endif //#ifndef DAPL_IKERNEL_QUALIFICATOR_HPP
