﻿#ifndef DAPL_KERNEL_ITER_HPP
#define DAPL_KERNEL_ITER_HPP

#include <iterator>
#include <list>
#include <memory>

template<class TT>
class tRootIterator : virtual public Root {
public:
	virtual TT& operator*() const = 0;
	virtual TT* operator->() const = 0;
	virtual bool operator==(const tRootIterator&) const = 0;
	virtual bool operator!=(const tRootIterator& src) const { return !operator==(src); }
protected:
	template<class T>
	friend class tIter;
	virtual std::shared_ptr<Root> clone() const = 0;
	virtual void inc() = 0;
	virtual void dec() = 0;
	virtual void set(const TT& pObj) const = 0;
};

template<class TT>
class tIter {
public:
	typedef std::list<int>::iterator::iterator_category iterator_category;
	typedef TT value_type;
	typedef ptrdiff_t difference_type;
	typedef TT* pointer;
	typedef TT& reference;

private:
	std::shared_ptr<tRootIterator<TT>> it;

public:
	tIter() : it() {}
	tIter(const tIter<TT>& src) : it() {
		if (src.it)
			it = std::dynamic_pointer_cast<tRootIterator<TT>>(src.it->clone());
	}
	tIter(const std::shared_ptr<tRootIterator<TT>>& src) : it() {
		if (src)
			it = std::dynamic_pointer_cast<tRootIterator<TT>>(src->clone());
	}
	tIter(const tRootIterator<TT>* src) : it() {
		if (src) {
			std::shared_ptr<const tRootIterator<TT>> tmp(src);
			it = std::dynamic_pointer_cast<tRootIterator<TT>>(src->clone());
		}
	}

	virtual ~tIter() {}

	inline std::shared_ptr<tRootIterator<TT>> getRootIterator() const { return it; }

	inline TT& operator*() const {
		return *(*it);
	}
	inline TT* operator->() const {
		return (*it).operator->();
	}
	inline operator const TT* () const {
		return (*it).operator->();
	}
	inline tIter<TT>& operator=(const tRootIterator<TT>* src) {
		it = (src) ? std::dynamic_pointer_cast<tRootIterator<TT>>(src->clone()) : nullptr;
		return *this;
	}
	inline tIter<TT>& operator=(const std::shared_ptr<tRootIterator<TT>> src) {
		it = (src) ? std::dynamic_pointer_cast<tRootIterator<TT>>(src->clone()) : nullptr;
		return *this;
	}
	inline tIter<TT>& operator=(const tIter<TT>& src) {
		it = (src.it) ? std::dynamic_pointer_cast<tRootIterator<TT>>(src.it->clone()) : nullptr;
		return *this;
	}
	inline tIter<TT>& operator++() {
		if (it != nullptr) it->inc();
		return *this;
	}
	inline tIter<TT>& operator--() {
		if (it != nullptr) it->dec();
		return *this;
	}
	inline tIter<TT> operator++(int) {
		tIter<TT> res(*this);
		if (it != nullptr) it->inc();
		return res;
	}
	inline tIter<TT>  operator--(int) {
		tIter<TT> res(*this);
		if (it != nullptr) it->dec();
		return res;
	}
	inline tIter<TT>& operator+=(ptrdiff_t n) {
		if (n < 0)
			return operator-=(-n);

		if (it != nullptr) {
			while (n-- > 0) it->inc();
		}
		return *this;
	}
	inline tIter<TT>& operator-=(ptrdiff_t n) {
		if (n < 0)
			return operator+=(-n);

		if (it != nullptr) {
			while (n-- > 0) it->dec();
		}
		return *this;
	}
	inline bool operator==(const tIter<TT>& src) const {
		if (it == nullptr)	return it == src.it;
		if (src.it == nullptr) return false;
		return (*it) == (*(src.it));
	}
	inline bool operator!=(const tIter<TT>& src) const {
		if (it == nullptr)	return it != src.it;
		if (src.it == nullptr) return true;
		return (*it) != (*(src.it));
	}
	inline void set(const TT& pObj) const {
		it->set(pObj);
	}
};

#endif
