
/// \file Kernel/types.hpp
/// Оперделение элементарных типов.
/// @ingroup Kernel
/// Файл содержит переорпделений названий элементарных типов в нотации библиотеки.

#ifndef DAPL_KERNEL_TYPES_HPP
#define DAPL_KERNEL_TYPES_HPP

#include <string>
#include <vector>

#include "ptr.hpp"

//=============================================================================
// Элементарные типы

/// Логически тип.
/// @ingroup Kernel
/// Для определения элементарных объектов контейнера данных вводится "логический тип".
/// \see IStorage , StorageData
typedef bool                Bool; 
/// Байт.
/// @ingroup Kernel
/// Для определения элементарных объектов контейнера данных вводится тип "байт".
/// \see IStorage , StorageData
typedef unsigned char       Byte;
/// Символ. 
/// @ingroup Kernel
/// Для определения элементарных объектов контейнера данных вводится тип "символ".
/// \see IStorage , StorageData
typedef char                Char;
/// Короткое целое число. 
/// @ingroup Kernel
/// Для определения элементарных объектов контейнера данных вводится тип "короткое целое число".
/// \see IStorage , StorageData
typedef short               Short;
/// Положительное короткое целое число. 
/// @ingroup Kernel
/// Для определения элементарных объектов контейнера данных вводится тип "положительное короткое целое число". 
/// \see IStorage , StorageData
typedef unsigned short      UShort;
/// Целое число. 
/// @ingroup Kernel
/// Для определения элементарных объектов контейнера данных вводится тип "целое число". 
/// \see IStorage , StorageData 
typedef long                Long;
/// Положительное целое число.
/// @ingroup Kernel
/// Для определения элементарных объектов контейнера данных вводится тип "положительное целое число".
/// \see IStorage , StorageData
typedef unsigned long       ULong;
/// Действительное число.
/// @ingroup Kernel
/// Для определения элементарных объектов контейнера данных вводится тип "действительное число".
/// \see IStorage , StorageData
typedef double              Real;
/// Длинное действительное число.
/// @ingroup Kernel
/// Для определения элементарных объектов контейнера данных вводится тип "длинное действительное число".
/// \see IStorage , StorageData
typedef long double         LReal;
/// Строка.
/// @ingroup Kernel
/// Для определения элементарных объектов контейнера данных вводится тип "строка".
/// \see IStorage , StorageData
typedef std::string         String;
/// Ссылка на контейнер.
/// @ingroup Kernel
/// Для определения элементарных объектов контейнера данных вводится специальный тип "ссылка на контейнер данных".
/// Например, при записи объекты такого типа сохраняются в неком едином массиве с уникальным 
/// идентификатором и если в этой же сессии сохранения записывается другой \c Ptr 
/// на этот же объект, то его данные не дублируются, а указывается только этот 
/// уникальный идентификатор. При востановлении соответсвенно создается только 
/// один объект и много ссылок на него.
typedef Ptr<Root>           RootRef;
/// Дата и время.
/// @ingroup Kernel
typedef unsigned int        DateTime;

#define DAPL_DATE_FORMAT "%d/%m/%Y"
#define DAPL_TIME_FORMAT "%H:%M:%S"
#define DAPL_DATETIME_FORMAT (DAPL_DATE_FORMAT "-" DAPL_TIME_FORMAT)

std::string time2string(DateTime tval, const char* format=DAPL_DATETIME_FORMAT);
DateTime string2time(const std::string& str, const char* format=DAPL_DATETIME_FORMAT);
std::vector<std::string> split(const std::string& str, const std::string& delimiters=" ");
/// Функция возвращает текущее локальное время (с учетом timezone).
DateTime ltime();
std::string stringf(const char* msg, ...);
std::string replace(std::string text, std::string s, std::string d);


#ifdef REAL_EPSILON
#undef REAL_EPSILON
#endif
#define REAL_EPSILON 2.2204460492503131e-016

#endif //#ifndef DAPL_IKERNEL_TYPES_HPP
