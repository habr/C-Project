﻿#include "ptr.hpp"

#include <iostream>

unsigned int Root::s_constructCounter{0};
unsigned int Root::s_deleteCounter{0};

// static
void Root::DetectLeaks() {
  if (Root::s_constructCounter == Root::s_deleteCounter)
    return;
  std::cerr << "MEMORY LEAKS in Root: constructed #" << Root::s_constructCounter
            << ", deleted #" << Root::s_deleteCounter << " => leaked #"
            << (Root::s_constructCounter - Root::s_deleteCounter) << "!\n";
}
