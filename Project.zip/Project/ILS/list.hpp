﻿
/// \file IKernel/list.hpp
/// Определение интерфейсов списков по Ptr-ам объектов.
/// @ingroup IKernel
/// Определение интерфейсов списков \c Ptr-ов.
#ifndef DAPL_IKERNEL_LIST_HPP
#define DAPL_IKERNEL_LIST_HPP

#include <algorithm>
#include <string>
#include <vector>

#include "iter.hpp"
#include "ptr.hpp"
#include "qualificator.hpp"
#include "types.hpp"

//=============================================================================
/// Шаблон интерфейса константного списка Ptr-ов на объекты некоторого типа.
/// @ingroup IKernel
/// Зачастую надо работать с некоторыми списками объектов, которые формируются различным образом.
/// Для этого вводится интерфейс списка Ptr-ов.
/// \param OTYPE - тип объекта на который указывают Ptr-ы данного списка.
/// \see tIter , tIPtrList
template<class OTYPE>
struct tIPtrListConst : virtual public Root {
	typedef tIter< Ptr<OTYPE> > const_iterator; // Тип итератора по объекта типа Ptr< OTYPE >.
	typedef tIter< Ptr<OTYPE> > iterator; // Тип итератора по объекта типа Ptr< OTYPE >.
	typedef tIter< Ptr<OTYPE> > Iterator; // Тип итератора по объекта типа Ptr< OTYPE >.
	typedef Ptr<OTYPE> Element;  // Тип элемента списка.
	/// Начало списка представленного объектом.
	virtual Iterator begin() const = 0;
	/// Конец списка представленного объектом.
	virtual Iterator end() const = 0;
	/// Размер списка, представленного данным объектом.
	virtual ULong size() const = 0;
	/// Первый элемент представленного списка.
	virtual Ptr<OTYPE> front() const = 0;
	/// Последний.
	virtual Ptr<OTYPE> back() const = 0;
	/// Элемент указанной позиции.
	/// Функция возвращает значение элемента в указанной позиии или NULL если такого нет.
	/// \note Если результат NULL нельзя определить, что произошло, выход за пределы массива или NULL-значение в массиве.
	/// \attention Функция перебирает работает долго, итератор от begin() увеличивается N раз и его значение возвращается.
	inline Iterator pos(size_t n) const {
		if (n >= size())
			return end();
		Iterator it = begin();
		while( n-- > 0) ++it;
		return it;
	}
	/// Элемент указанной позиции.
	/// Функция возвращает значение элемента в указанной позиии или NULL если такого нет.
	/// \note Если результат NULL нельзя определить, что произошло, выход за пределы массива или NULL-значение в массиве.
	/// \attention Функция перебирает работает долго, итератор от begin() увеличивается N раз и его значение возвращается.
	inline Ptr<OTYPE> at(size_t n) const {
		return *(pos(n));
	}
	/// Возвращает позицию указанного элемента
	virtual int GetPosition( const Element & pElement ) const
	{
		int iSearchResult = -1, iCounter = 0;
		const_iterator oIter = begin(), oIterEnd = end();
		while ( oIter != oIterEnd )
		{
			if ( *oIter == pElement )
			{
				iSearchResult = iCounter;
				oIter = oIterEnd;
			}
			else
			{
				oIter++;
				iCounter++;
			}
		}
		return iSearchResult;
  }
}; //struct tIPtrListConst

//=============================================================================
/// Шаблон интерфейса списка Ptr-ов на объекты некоторого типа.
/// @ingroup IKernel
/// Зачастую надо работать с некоторыми списками объектов, которые формируются различным образом.
/// Для этого вводится интерфейс списка Ptr-ов.
/// \param OTYPE - тип объекта на который указывают Ptr-ы данного списка.
/// \see tIter , tIPtrListConst
template<class OTYPE>
struct tIPtrList : virtual public tIPtrListConst<OTYPE> {
	typedef tIter< Ptr<OTYPE> > iterator; // Тип итератора по объекта типа Ptr< OTYPE >.
	typedef tIter< Ptr<OTYPE> > Iterator; // Тип итератора по объекта типа Ptr< OTYPE >.
	using tIPtrListConst<OTYPE>::pos;
										  /// Начало списка представленного объектом.
	virtual Iterator begin() const = 0;
	/// Конец списка представленного объектом.
	virtual Iterator end() const = 0;
	/// Размер списка, представленного данным объектом.
	virtual ULong size() const = 0;
	/// Первый элемент представленного списка.
	virtual Ptr<OTYPE> front() const = 0;
	/// Последний.
	virtual Ptr<OTYPE> back() const = 0;
	/// Добавление нового элемента в конец списка.
	virtual void push_back(const Ptr<OTYPE>&) = 0;
	/// Добавление нового элемента в начало списка.
	virtual void push_front(const Ptr<OTYPE>&) = 0;
	/// Добавление нового элемента в произвольное место списка.
	virtual Iterator insert( const Iterator & it, const Ptr <OTYPE> & ) = 0;
	/// Удаление элемента в конце списка.
	virtual void pop_back() = 0;
	/// Удаление элемента в начале списка.
	virtual void pop_front() = 0;
	// Перемещение элемента на новую позицию в этом же списке
	virtual void splice(const Iterator& newPosition, Iterator& it) = 0;
	/// Удаление элемента определенного своим итератором.
	/// Функция удаляет из списка объект, на который указывает переданнй итератор.
	/// \param it - итератор на объект, который надо удалить из списка.
	/// \return итератор на элемет, который следовал сразу за только что удаленным.
	virtual Iterator erase(const Iterator& it) = 0;
	/// Меняет значения двух итераторов.
	virtual void swap( const Iterator & oFirstIter, const Iterator & oSecondIter ) = 0;
	/// Меняет значения номеров в списке.
	/// Функция ищет элементы последовательным перебором, медленно
	inline void swap(size_t iFirst, size_t iSecond) {
		Iterator oFirstIter = begin();
		oFirstIter += iFirst;
		Iterator oSecondIter = begin();
		oSecondIter += iSecond;
		swap(oFirstIter, oSecondIter);
	}
	/// Аналог std::rotate
	/// @todo НЕ ОПТИМАЛЬНО, надо ускорить
	virtual void rotate (Iterator first, Iterator middle, Iterator last) = 0;
	/// Аналог std::rotate
	/// @todo НЕ ОПТИМАЛЬНО, надо ускорить
	inline void rotate (size_t first, size_t middle, size_t last) {
		Iterator oFirstIter = pos(first);
		Iterator oMiddleIter = pos(middle);
		Iterator oLastIter = pos(last);
		rotate(oFirstIter, oMiddleIter, oLastIter);
	}
	/// Полная очистка списка.
	virtual void clear() = 0;
	/// Изменение размера.
	/// Функция изменяет размер предмета. Эта функция добавляет (или убирает) элементы предмета, чтобы
	/// окончательный размер предмета был равен указанному числу. При этом в качестве новых предметов
	/// добавляются NULL.
	/// \param new_sz - новый размер списка.
	virtual void resize(ULong new_sz) = 0;
	/// Вставка списка элементов в конец данного списка.
	template<class InputIterator> inline void push_back(InputIterator _first, InputIterator _last) {
		for(InputIterator it=_first;it!=_last;++it) {
			push_back(*it);
		}
	}

	/// Очистка списка от "пустых" элементов.
	/// Функция освобождает список от "пустых" элементов. Понятие "пустого" элемета
	/// может быть разным в зависимости от типа элемента. В общем случае (и такакя реализация по умолчанию)
	/// функция удаляет из списка те Ptr-ы, которые указывают на NULL, однако для некоторых типов элементов,
	/// понятие "пустого элемента" может быть шире и зависить от характеристик элемента.
	/// \return количество "удаленных" из списка пустых элементов.
	virtual ULong purge() {
		Iterator it=begin();
		ULong count=0;
		while(it!=end()) {
			if(it->get()==NULL) {it=erase(it);++count;}
			else ++it;
		}
		return count;
	}
	/// Очистка списка от "пустых" элементов со смещением итератора.
	/// Функция освобождает список от "пустых" элементов, смещпая при этом указанный итератор на следующий непустой. 
	/// Понятие "пустого" элемета может быть разным в зависимости от типа элемента. В общем случае (и такакя реализация по умолчанию)
	/// функция удаляет из списка те Ptr-ы, которые указывают на NULL, однако для некоторых типов элементов,
	/// понятие "пустого элемента" может быть шире и зависить от характеристик элемента.
	/// \return количество следующий непустой итератор за iter, если iter не пустой, то возвращается он сам.
	virtual Iterator purge(const Iterator& iter) {
		Iterator res=iter;
		while(res->get()==NULL&&res!=end()) ++res;
		Iterator it=begin();
		while(it!=end()) {
			if(it->get()==NULL) it=erase(it);
			else ++it;
		}
		return res;
	}
	/// Удаление элементов, удовлетворяющих условию.
	/// Функция получаетя функцию, которая получает на вход указатель на элемент и возвращает true, 
	/// если этот элемент надо удалить из списка.
	template<typename FUNC> void removeIf(FUNC f) {
		Iterator it = begin();
		while (it != end()) {
			if (f(it->get())) it = erase(it);
			else ++it;
		}
	}
	/// Квалификация всех элементов.
	/// Функция квалифицирует все элементы списк с помощью переданного квалификатора.
	/// \param qual - указатель на квалификатор, класс, который квалифицирует элементы списка.
	/// \attention Для применения этой функции все элементы списка должны быть ненулевыми Ptr-рами на квалифицирумые объекты (наследники класса tQualified).
	/// \warning Вызов этой функции квалифицирует все элементы списка, то есть присваивает каждому их них новое квалификационное значение, стирая при этом старое.
	/// \note Обычно эта функция применяется для последующей сортировки элементов списка в соответвии с квалификационным значением.
	/// \see tIPtrList::qualifySort() , IQualified , IQualificator , tQualifyComparator
	virtual void qualify(const IQualificator* qual) = 0;
	/// Сортировка всех элементов в соответствии с установленным квалификационным значением.
	/// Функция сортирует все элементы в порядке убывания или возрастания квалификационных значений.
	/// \param descend_sort - тип сортировки элементов, true - по убыванию квалификационного значения, false - по возрастанию.
	/// \attention Данная функция не квалифицирует предметы, все оди долюны быфть квалифицированны до ее вызова.
	/// \attention Для применения этой функции все элементы списка должны быть ненулевыми Ptr-рами на квалифицирумые объекты (наследники класса tQualified).
	/// И все они дожны быть квалифицированны заранее, т.е. вызов функции \c tIQualified::wasQualified() для элемента должен возвращать true.
	/// \see tIPtrList::qualify() , IQualified , IQualificator , tQualifyComparator
	virtual void qualifySort(bool descend_sort=true) = 0;
	/// Стабильная сортировка всех элементов в соответствии с установленным квалификационным значением.
	/// Функция сортирует стабильным обрахом все элементы в порядке убывания или возрастания квалификационных значений.
	/// Под стабильной сотировкой понимаетмя такая, которая сохраняет последовательность равных (с точки зрения сортировки) элементов.
	/// \param descend_sort - тип сортировки элементов, true - по убыванию квалификационного значения, false - по возрастанию.
	/// \attention Данная функция не квалифицирует предметы, все оди долюны быфть квалифицированны до ее вызова.
	/// \attention Для применения этой функции все элементы списка должны быть ненулевыми Ptr-рами на квалифицирумые объекты (наследники класса tQualified).
	/// И все они дожны быть квалифицированны заранее, т.е. вызов функции \c tIQualified::wasQualified() для элемента должен возвращать true.
	/// \see tIPtrList::qualify() , IQualified , IQualificator , tQualifyComparator
	virtual void qualifyStableSort(bool descend_sort=true) = 0;
	/// Стабильная пересортировка предметов по указанному функционалу.
	template<class COMP> void stableSort(COMP comp) {
		// екарныбабай 8( 
		// std::stable_sort можно применять только к итераторам произвольного доступа, а у меня все работа уже заточена на список.
		// переделывать много и долго, не буду. Вместо это сделаю два копирования всех элементов списка, благо эта 
		// функция будет вызываться редко, да и +2N к скорости работы сортировки не так много.
		std::vector< Ptr<OTYPE> > v(size());
		std::copy(begin(), end(), v.begin());
		std::stable_sort(v.begin(),v.end(),comp);
		// std::copy(v.begin(), v.end(), item_set->begin()); - не работает почему-то
		clear();
		for(ULong i=0;i<v.size();++i) push_back(v[i]);
	}
}; //struct tIPtrList

//=============================================================================
/// Шаблон стандартной реализации интерфейса списка Ptr-ов на объекты некоторого типа.
/// @ingroup IKernel
/// В большинстве случаев реализация интервейсов списков - это реализация доступа к
/// некоторому стаднартному списку std::list. Вот такую реализацию и определяет данный шаблон.
/// \param LTYPE - тип объектов, Ptr-ы на которые реалльно храняться в списке типа std::list.
/// \param ITYPE - тип объектов, список Ptr-ов на которые, должен быть представлен интерфейсом, который реализует данный объект.
/// \param CTYPE - двупараметрический шаблон типа контейнера, к которому предоставляет интерфейсы данная реализация (по умолчанию std::list), тип дожен обладать функциями итерирования.
/// \param ATYPE - однопараметрический шаблон аллокатора данных, второй параметр шаблона CTYPE.
/// \attention Нельзя изменять сам Ptr, на который ссылается этот итератор, это изменение не приведет к изменению списка и будет проигнорированно.
/// Можно изменять только сами объекты, на которые указывает \c Ptr. Пример подобной НЕПРАВИЛЬНОЙ работы можно посмотреть в файле \link list_examp2.cpp list_examp2.cpp \endlink .
/// \see tIter , tIPtrList
template<class LTYPE, class ITYPE, class CTYPE=std::list<Ptr<LTYPE>>>
class tStdPtrList : virtual public tIPtrList<ITYPE> {
	typedef LTYPE LType;
	typedef ITYPE IType;
public:
	typedef tStdPtrList<LTYPE,ITYPE, CTYPE> ThisType;
	typedef CTYPE StdList;
	typedef typename StdList::const_iterator StdConstListIterator;
	typedef typename StdList::iterator StdListIterator;
	typedef tIter< Ptr<ITYPE> > iterator; // Тип итератора по объекта типа Ptr< OTYPE >.
	typedef tIter< Ptr<ITYPE> > Iterator; // Тип итератора по объекта типа Ptr< OTYPE >.
protected: // главные функции, которые должны быть реализованы.
	/// Доступ к стандратному списку константум образом.
	/// Функция обеспечивает досут к стандартному списку типа std::list
	/// константым образом.
	virtual const StdList& getStdListRefConst() const = 0;
	/// Доступ к стандратному списку.
	/// Функция обеспечивает досут к стандартному списку типа std::list.
	virtual StdList& getStdListRef() = 0;
	/// Преобразование реальных Ptr-ов в интерфейсные.
	/// Функция преобразует Ptr как элемент стандартного списка в Ptr, 
	/// список которых представляет интерфейс.
	/// \note По умолчанию эта функция реализована как dynamic_cast одного указателя 
	/// на другой, однако может быть переопределена в наследниках.
	virtual Ptr<ITYPE> l2iConvertPtr(const Ptr<LTYPE>& p) const {
		return dynamic_cast<IType*>(p.get());
	}
	/// Преобразование интерфейсных Ptr-ов в реальные.
	/// Функция преобразует Ptr как элемент интерфейса в Ptr-ы, 
	/// как элементы реального списка std::list по которуму производится итерирование.
	/// \note По умолчанию эта функция реализована как dynamic_cast одного указателя 
	/// на другой, однако может быть переопределена в наследниках.
	virtual Ptr<LTYPE> i2lConvertPtr(const Ptr<ITYPE>& p) const {
		return dynamic_cast<LType*>(p.get());
	}
protected:
	//=============================================================================
	/// Реализация итератора по элементам списка.
	/// Данный класс реализует итератор по элементам списка.
	/// \param LTYPE - тип объектов, Ptr-ы на которые реалльно храняться в списке типа std::list.
	/// \param ITYPE - тип объектов, список Ptr-ов на которые, должен быть представлен интерфейсом, который реализует данный объект.
	/// \attention Нельзя изменять сам Ptr, на который ссылается этот итератор, это изменение не приведет к изменению списка и будет проигнорированно.
	/// Можно изменять только сами объекты, на которые указывает \c Ptr. Пример подобной НЕПРАВИЛЬНОЙ работы можно посмотреть в файле \link list_examp2.cpp list_examp2.cpp \endlink .
	/// \see tStdPtrList
	class RootIteratorImpl : virtual public tRootIterator<Ptr<ITYPE>> {
  public:
		template<class T1, class T2, class T3> friend class tStdPtrList;
		typedef CTYPE StdList;
		typedef tStdPtrList<LTYPE,ITYPE,CTYPE> BasePtrList;
		typedef typename StdList::iterator BaseIterator;       // Типа итератора по списку типа std::list, по которому реально придется итерироваться.
		BaseIterator it;                                       // Реальный итератор по сипску std::list, фнукционалльность которого повторяет данный.
		Ptr< const BasePtrList > p_list;                       // Указатель на стандартную реализацию списка, по которому итерируется данный объект.
		mutable Ptr<ITYPE> obj_ptr;                            // Ptr на объект типа \c ITYPE, на который указывает данный итератор.
		/// Обновление значения \c obj_ptr.
		/// Вспомогательная функция, которая приводит \c obj_ptr в соответвие с текущим значением it.
		inline void refreshPtr() const {
			if(it!=const_cast<StdList&>(p_list->getStdListRefConst()).end())
				obj_ptr=p_list->l2iConvertPtr(*it);
			else obj_ptr=NULL;
		}
  public:
		/// Конструктор итератора.
		/// Сконструировать итератор можно только из функций шаблона класса \c tStdPtrList, обязательно указав
		/// на базе какого итаратора стандартного списка строится данный и указаетль на стандартную реализайию списка.
		RootIteratorImpl(const BaseIterator& i, const BasePtrList* l) : it(i),p_list(l) {refreshPtr();}
		/// Конструктор копирования.
		/// При копировании объектов правильно должны указать Ptr на объект.
		RootIteratorImpl(const RootIteratorImpl& i) : it(i.it),p_list(i.p_list) {refreshPtr();}
	public: // реализация функций класса tRootIterator<ITYPE>
		virtual Ptr<ITYPE>& operator*()  const {return obj_ptr;}
		virtual Ptr<ITYPE>* operator->() const {return &obj_ptr;}
		virtual bool operator==(const tRootIterator< Ptr<ITYPE> >& src) const {
			try {
				const RootIteratorImpl& iref = dynamic_cast<const RootIteratorImpl&>(src);
				return it==iref.it&&p_list==iref.p_list;
			} catch(...) {return false;}
		}

		Root* clone() const override { return new RootIteratorImpl(*this); }

		virtual void inc() {++it;refreshPtr();}
		virtual void dec() {--it;refreshPtr();}
		inline BaseIterator iter() const {return it;}
		virtual void set(const Ptr<ITYPE>& pObj) const {
			*it = pObj.template cast<LTYPE>();
			refreshPtr();
		}

	private:
		virtual std::string typeId() const {return "RootIteratorImpl";}
	};

	friend class RootIteratorImpl;

	/// Внутреняя реализация добавления в начала списка.
	/// Не все контейнеры, к которым строится этот интерфейс имеют функцию добавления в начало списка,
	/// поэтому эта функция определяется шаблонным образом, и специально переопределяется для таких контейнеров.
	/// Например, для std::vector
	template<class CNTR> void push_front_internal(const Ptr<ITYPE>& e) {
		getStdListRef().push_front(i2lConvertPtr(e));
	}
#ifdef _MSC_VER
	template<> void push_front_internal<std::vector<Ptr<LType>>>(const Ptr<ITYPE>& e) {
	}
#endif //#ifdef _MSC_VER
	/// Внутреняя реализация сортировки.
	/// Не все контейнеры, к которым строится этот интерфейс имеют функцию сортировки,
	/// поэтому эта функция определяется шаблонным образом, и специально переопределяется для таких контейнеров.
	/// Например, для std::vector
	template<class CNTR> void qualifySort_internal(bool descend_sort) {
		getStdListRef().sort(tQualifyComparator< Ptr<LType> >(descend_sort));
	}
#ifdef _MSC_VER
	template<> void qualifySort_internal<std::vector<Ptr<LType>>>(bool descend_sort) {
		std::sort(getStdListRef().begin(),getStdListRef().end(),tQualifyComparator< Ptr<LTYPE> >(descend_sort));
	}
#endif //#ifdef _MSC_VER
public: //реализация функций интерфейса tIPtrListConst
	virtual Iterator begin() const {return Iterator(new RootIteratorImpl(const_cast<StdList&>(getStdListRefConst()).begin(),this));}
	virtual Iterator end() const {return Iterator(new RootIteratorImpl(const_cast<StdList&>(getStdListRefConst()).end(),this));}
	virtual ULong size() const {return ULong(getStdListRefConst().size());}
	virtual Ptr<ITYPE> front() const {return l2iConvertPtr(getStdListRefConst().front());}
	virtual Ptr<ITYPE> back() const {return l2iConvertPtr(getStdListRefConst().back());}
	virtual void resize(ULong new_sz) {getStdListRef().resize(new_sz);}
public: //реализация функций интерфейса tIPtrList
	virtual Iterator insert( const Iterator & it, const Ptr <ITYPE> & e ) {
		RootIteratorImpl* i = dynamic_cast<RootIteratorImpl*>(it.getRootIterator().get());
		if(i==NULL) return it;
		Iterator result = Iterator(new RootIteratorImpl(getStdListRef().insert( i->it, i2lConvertPtr(e) ),this));
		afterAdding(result);
		return result;
	}
	virtual void push_back(const Ptr<ITYPE>& e)  {
		getStdListRef().push_back(i2lConvertPtr(e));
		afterAdding(--end());
	}
	virtual void push_front(const Ptr<ITYPE>& e) {
		push_front_internal<CTYPE>(e); // см. комментарий к push_front_internal()
		afterAdding(begin());
	}
	virtual void pop_back() {
		Iterator e = end();
		beforeRemove(--e);
		getStdListRef().pop_back();
		//afterRemove();
	}
	virtual void pop_front()
	{
		beforeRemove(begin());
		getStdListRef().pop_front();
		//afterRemove();
	}
	virtual void splice(const Iterator& newPosition, Iterator& it) {
		RootIteratorImpl* i = dynamic_cast<RootIteratorImpl*>(it.getRootIterator().get());
		RootIteratorImpl* newPos = dynamic_cast<RootIteratorImpl*>(newPosition.getRootIterator().get());
		getStdListRef().splice(newPos->it, getStdListRef(), i->it);
	}
	virtual Iterator erase(const Iterator& it) {
		RootIteratorImpl* i = dynamic_cast<RootIteratorImpl*>(it.getRootIterator().get());
		if(i==NULL) return it;
		beforeRemove(it);
		Iterator res = new RootIteratorImpl(getStdListRef().erase(i->it),this);
		//afterRemove();
		return res;
	}
	/// меняет значения двух итераторов
	virtual void swap( const Iterator & oFirstIter, const Iterator & oSecondIter )
	{
		// Просто так поменять нельзя так как operator*() возвращает КОПИЮ Ptr,
		// присвоение которой ничего не даст!!!
		Ptr<ITYPE> pFirstValue = *oFirstIter;
		oFirstIter.set(*oSecondIter);
		oSecondIter.set(pFirstValue);
	}
	/// Аналог std::rotate
	/// @todo НЕ ОПТИМАЛЬНО, надо ускорить
	virtual void rotate (Iterator first, Iterator middle, Iterator last)
	{
		typename StdList::iterator f = dynamic_cast<RootIteratorImpl*>(first.getRootIterator().get())->it;
		typename StdList::iterator m = dynamic_cast<RootIteratorImpl*>(middle.getRootIterator().get())->it;
		typename StdList::iterator l = dynamic_cast<RootIteratorImpl*>(last.getRootIterator().get())->it;
		std::rotate(f, m, l);
	}
	virtual void clear() {
		beforeClear();
		getStdListRef().clear();
	}
	virtual ULong purge() {
		// для ускорения переопределяем функцию чистки для работы с итераторами std-списка
		StdListIterator it=getStdListRef().begin();
		ULong count=0;
		while(it!=getStdListRef().end()) {
			if(it->get()==NULL) {it=getStdListRef().erase(it);++count;}
			else ++it;
		}
		return count;
	}
	virtual Iterator purge(const Iterator& iter) {
		Iterator res=iter;
		while(res->get()==NULL&&res!=end()) ++res;
		// для ускорения переопределяем функцию чистки для работы с итераторами std-списка
		StdListIterator it=getStdListRef().begin();
		while(it!=getStdListRef().end()) {
			if(it->get()==NULL) it=getStdListRef().erase(it);
			else ++it;
		}
		return res;
	}
	virtual void qualify(const IQualificator* qual) {
		qual->qualify(getStdListRef().begin(),getStdListRef().end());
	}
	virtual void qualifySort(bool descend_sort=true) {
		qualifySort_internal<CTYPE>(descend_sort);// см. комментарии к qualifySort_internal()
	}
	virtual void qualifyStableSort(bool descend_sort=true) {
		// екарныбабай 8(
		// std::stable_sort можно применять только к итераторам случайного доступа, а у меня все работа уже заточена на список.
		// переделывать много и долго, не буду. Вместо это сделаю два копирования всех элементов списка, благо эта
		// функция будет вызываться редко, да и +2N к скорости работы сортировки не так много.
		std::vector< Ptr<LType> > v(getStdListRef().size());
		std::copy(getStdListRef().begin(), getStdListRef().end(), v.begin());
		std::stable_sort(v.begin(),v.end(),tQualifyComparator< Ptr<LType> >(descend_sort));
		// std::copy(v.begin(), v.end(), getStdListRef().begin()); - не работает почему-то
		getStdListRef().clear();
		for(ULong i=0;i<v.size();++i) getStdListRef().push_back(v[i]);
	}
protected:
  /// Перед удалением элемента.
	/// Функция вызывается перед удалением итератора из списка.
	virtual void beforeRemove(const Iterator& iter) {};
  /// Перед очисткой списка.
	virtual void beforeClear() {};
  /// После добавления элемента
	virtual void afterAdding(const Iterator& iter) {};
public:
	// см. комментарий к Root::preDestroy();
	virtual void preDestroy() {getStdListRef().clear();}
}; // struct tStdPtrList

//=============================================================================
/// Шаблон реализации интерфейса списка Ptr-ов, путем ссылки на другой список.
/// @ingroup IKernel
/// Зачастую удобно чтобы класс реализовывал интерфейс списка, при этом все 
/// вызовы функция этого интерфейса просто переправлял к некоторому другому 
/// списку, через этот же интерфейс.
/// \param OTYPE - тип объекта на который указывают Ptr-ы данного списка.
/// \see tIter , tIPtrListConst
template<class OTYPE>
class tRefPtrListConst : virtual public tIPtrListConst<OTYPE> {
	/// Указатель на список, который реально его содержит.
	virtual tIPtrListConst<OTYPE>* getRefPtrList() const = 0;
public:
	typedef typename tIPtrList<OTYPE>::Iterator Iterator;
	virtual Iterator begin() const {return getRefPtrList()->begin();}
	virtual Iterator end() const  {return getRefPtrList()->end();}
	virtual ULong size() const  {return getRefPtrList()->size();}
	virtual Ptr<OTYPE> front() const  {return getRefPtrList()->front();}
	virtual Ptr<OTYPE> back() const  {return getRefPtrList()->back();}
}; //struct tRefPtrListConst

//=============================================================================
/// Шаблон реализации интерфейса списка Ptr-ов, путем ссылки на другой список.
/// @ingroup IKernel
/// Зачастую удобно чтобы класс реализовывал интерфейс списка, при этом все 
/// вызовы функция этого интерфейса просто переправлял к некоторому другому 
/// списку, через этот же интерфейс.
/// \param OTYPE - тип объекта на который указывают Ptr-ы данного списка.
/// \see tIter , tIPtrListConst
template<class OTYPE>
class tRefPtrList : virtual public tIPtrList<OTYPE> {
	/// Указатель на список, который реально его содержит.
	virtual tIPtrList<OTYPE>* getRefPtrList() const = 0;
public:
	typedef typename tIPtrList<OTYPE>::Iterator Iterator;
	virtual Iterator begin() const {return getRefPtrList()->begin();}
	virtual Iterator end() const  {return getRefPtrList()->end();}
	virtual ULong size() const  {return getRefPtrList()->size();}
	virtual Ptr<OTYPE> front() const  {return getRefPtrList()->front();}
	virtual Ptr<OTYPE> back() const  {return getRefPtrList()->back();}
	virtual void push_back(const Ptr<OTYPE>& o)  {getRefPtrList()->push_back(o);}
	virtual void push_front(const Ptr<OTYPE>& o)  {getRefPtrList()->push_front(o);}
	virtual Iterator insert( const Iterator & it, const Ptr <OTYPE> & o ) { return getRefPtrList()->insert( it, o ); }
	virtual void pop_back() {getRefPtrList()->pop_back();}
	virtual void pop_front() { getRefPtrList()->pop_front(); }
	virtual void splice(const Iterator& newPosition, Iterator& it) { getRefPtrList()->pop_front(newPosition, it); }
	virtual Iterator erase(const Iterator& it)  {return getRefPtrList()->erase(it);}
	virtual void swap( const Iterator & it1, const Iterator & it2 ) {return getRefPtrList()->swap(it1,it2);}
	virtual void clear() {getRefPtrList()->clear();}
	virtual void resize(ULong new_sz)  {getRefPtrList()->resize(new_sz);}
	virtual Iterator insert(Iterator where, const Ptr<OTYPE>& val) {return getRefPtrList()->insert(where,val);}
	virtual ULong purge()  {return getRefPtrList()->purge();}
	virtual Iterator purge(const Iterator& iter)  {return getRefPtrList()->purge(iter);}
	virtual void qualify(const IQualificator* qual)  {getRefPtrList()->qualify(qual);}
	virtual void qualifySort(bool descend_sort=true)  {getRefPtrList()->qualifySort(descend_sort);}
	virtual void qualifyStableSort(bool descend_sort=true)  {getRefPtrList()->qualifyStableSort(descend_sort);}
}; //struct tRefPtrList

//=============================================================================
/// Шаблон реализации интерфейса фиксированного списка Ptr-ов.
/// @ingroup IKernel
/// В некоторых случаях фиксированный набор элементов надо представить в виде списка элементов (естественно константного).
/// Данный шаблон реализует фукнции интерфейса списка, по фиксированному набор элементов. 
/// \param ENUM - количество элементов констарнтного списка.
/// \param ITYPE - тип объектов, список Ptr-ов на которые, должен быть представлен интерфейсом, который реализует данный объект.
/// \attention Нельзя изменять сам Ptr, на который ссылается этот итератор, это изменение не приведет к изменению списка и будет проигнорированно.
/// Можно изменять только сами объекты, на которые указывает \c Ptr. Пример подобной НЕПРАВИЛЬНОЙ работы можно посмотреть в файле \link list_examp2.cpp list_examp2.cpp \endlink .
/// \see tIter , tIPtrList
template<class ITYPE>
class tArrPtrList : virtual public tIPtrListConst<ITYPE> {
	virtual Ptr<ITYPE> getElement(int index) const = 0;
private:
	//=============================================================================
	/// Реализация итератора по элементам списка.
	/// Данный класс реализует итератор по элементам списка.
	/// \param ITYPE - тип объектов, список Ptr-ов на которые, должен быть представлен интерфейсом, который реализует данный объект.
	/// \attention Нельзя изменять сам Ptr, на который ссылается этот итератор, это изменение не приведет к изменению списка и будет проигнорированно.
	/// Можно изменять только сами объекты, на которые указывает \c Ptr. Пример подобной НЕПРАВИЛЬНОЙ работы можно посмотреть в файле \link list_examp2.cpp list_examp2.cpp \endlink .
	class ArrIteratorImpl : virtual public tRootIterator< Ptr<ITYPE> > {
		template<class T> friend class tArrPtrList;
		typedef tArrPtrList<ITYPE> BasePtrList;
		int index;                          // Значенение индекса.
		Ptr< const BasePtrList > p_list;    // Указатель на стандартную реализацию списка, по которому итерируется данный объект.
		mutable Ptr<ITYPE> obj_ptr;         // Ptr на объект типа \c ITYPE, на который указывает данный итератор.
		/// Обновление значения \c obj_ptr.
		/// Вспомогательная функция, которая приводит \c obj_ptr в соответвие с текущим значением it.
		inline void refreshPtr() const {
			if(p_list==NULL) return;
			if(index<0 || index>=int(p_list->size())) return;
			if(p_list==NULL || index<0 || index>=int(p_list->size())) obj_ptr=NULL;
			else obj_ptr=p_list->getElement(index);
		}
		/// Конструктор итератора.
		/// Сконструировать итератор можно только из функций шаблона класса \c tStdPtrList, обязательно указав 
		/// на базе какого итаратора стандартного списка строится данный и указаетль на стандартную реализайию списка.
		ArrIteratorImpl(const int& i, const BasePtrList* l) : index(i),p_list(l) {refreshPtr();}
		/// Конструктор копирования.
		/// При копировании объектов правильно должны указать Ptr на объект.
		ArrIteratorImpl(const ArrIteratorImpl& i) : index(i.index),p_list(i.p_list) {refreshPtr();}
	public: // реализация функций класса tRootIterator<ITYPE>
		virtual Ptr<ITYPE>& operator*()  const {return obj_ptr;}
		virtual Ptr<ITYPE>* operator->() const {return &obj_ptr;}
		virtual bool operator==(const tRootIterator< Ptr<ITYPE> >& src) const {
			try {
				const ArrIteratorImpl& iref = dynamic_cast<const ArrIteratorImpl&>(src);
				return index==iref.index&&p_list==iref.p_list;
			} catch(...) {return false;}
		}

		Root* clone() const override { return new ArrIteratorImpl(*this); }

		virtual void inc() {++index;refreshPtr();}
		virtual void dec() {--index;refreshPtr();}

	private:
		virtual std::string typeId() const {return "ArrIteratorImpl";}
	};

	friend class ArrIteratorImpl;

public: //реализация функций интерфейса tIPtrListConst
	typedef typename tIPtrListConst<ITYPE>::Iterator Iterator;
	virtual Iterator begin() const {return Iterator(new ArrIteratorImpl(0,this));}
	virtual Iterator end() const {return Iterator(new ArrIteratorImpl(size(),this));}
	virtual ULong size() const = 0;
	virtual Ptr<ITYPE> front() const {return getElement(0);}
	virtual Ptr<ITYPE> back() const {return getElement(size()-1);}
	virtual void resize(ULong new_sz) {}
}; //class tArrPtrList

#endif //#ifndef DAPL_IKERNEL_LIST_HPP
