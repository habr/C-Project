﻿#ifndef DAPL_KERNEL_PTR_HPP
#define DAPL_KERNEL_PTR_HPP
#include <stdio.h>
#include <set>
#include <string>
#include <map>
#include <mutex>
#include <vector>
class Root;
typedef std::map<Root*, Root*> CloneMap;
class Root {
public:
	typedef ::CloneMap CloneMap;
	template<class T> friend class Ptr;
protected:
private:
	mutable int ref_count;
public:
	Root() : ref_count(0) {}
	Root(const Root&) : ref_count(0) {}
	Root(Root&&) = delete;
	Root& operator=(const Root&) { return *this; }
	Root& operator=(Root&&) = delete;
	virtual void preDestroy() {}
	virtual void* rootThis() const {return (void*)(this);}
	virtual std::string typeId() const {
		return typeid(*this).name();
	}
	virtual Root* clone(CloneMap* clone_map=NULL, Root* clone_obj=NULL) const {return clone_obj;}
	inline Root* cloneSmart(CloneMap* clone_map, Root* clone_obj=NULL) const {
		if(clone_map) {
			CloneMap::const_iterator it = clone_map->find(const_cast<Root*>(this));
			if(it!=clone_map->end()) {
				return it->second;
    		}
		}
		return clone(clone_map,clone_obj);
	}
	template<class CLS>
	inline CLS* cloneAdd(CloneMap* clone_map, CLS* new_ptr) const {
		if(clone_map) (*clone_map)[const_cast<Root*>(this)] = new_ptr;
		return new_ptr;
	}
	inline int refCount() const { return ref_count; }
public: 
	friend class BasePtr;
	void rootAdd() const {
		++ref_count; 
	}
	void rootRelease() const {
		if (ref_count > 1) {
			--ref_count;
		} else {
			const_cast<Root*>(this)->preDestroy();
			delete this; 
		} 
	}
	void rootDetach() const {
		if (ref_count > 0) --ref_count;
	}
	protected:
		virtual ~Root() {}
public:
  static void DetectLeaks();

private:
  struct TLifetimeTracker {
    TLifetimeTracker() { ++Root::s_constructCounter; }
    ~TLifetimeTracker() { ++Root::s_deleteCounter; }
  };

  static unsigned int s_constructCounter;
  static unsigned int s_deleteCounter;

  TLifetimeTracker m_lifetimeTracker;
}; 
class BasePtr
{

protected:

	void addPtr( const Root * obj )
	{
		if ( obj )
			obj->rootAdd();
	}

	void releasePtr( const Root * obj )
	{
		if ( obj )
			obj->rootRelease();
	}

	void deatachPtr( const Root * obj )
	{
		if ( obj )
			obj->rootDetach();
	}

};
template<class OBJ> class Ptr : private BasePtr {
	template<class T> friend class Ptr;
	OBJ *obj;
public:
	typedef OBJ Object;
	Ptr(OBJ* in = NULL) { obj = in; addPtr(obj); }
	Ptr(const Ptr& in) { obj = in.obj; addPtr(obj); }
	template <class OBJ1> Ptr(const Ptr<OBJ1> &in) {
		obj = (OBJ*)in.get();  addPtr(obj);
	}
	~Ptr() {releasePtr(obj); obj = NULL;}
	OBJ* detach() {
		if (obj) {
			Object *o = obj;
			deatachPtr(obj);
			obj = NULL;
			return o;
		}
		return NULL;
	};
	Ptr& operator=(const Ptr<OBJ> &in) {
		if (in.obj!=obj) {
			Object *temp_obj=obj;
			obj=in.obj;
			addPtr(obj);
			releasePtr(temp_obj);
		} 
		return *this;
	}
	template <class OBJ1> Ptr& operator=(const Ptr<OBJ1> &in) {
		if (in.obj!=obj) {
			Object *temp_obj=obj;
			obj=in.obj;
			addPtr(obj);
			releasePtr(temp_obj);
		} 
		return *this;
	}
	Ptr& operator=(OBJ *in) {
		if (obj!=in) {
			Object* temp_obj=obj;
			obj=in;
			addPtr(obj);
			releasePtr(temp_obj);
		}
		return *this;
	}
        template <class OBJ1> bool operator==(const Ptr<OBJ1> &in) const {
		return obj==in.obj;
	}
	template <class OBJ1> bool operator!=(const Ptr<OBJ1> &in) const {
		return obj!=in.obj;
	}
	bool operator<(const Ptr &in) const {
		return obj<in.obj;
	}
	bool operator>(const Ptr &in) const {
		return obj>in.obj;
	}
	operator OBJ*() const {return obj; }
	OBJ* get() const {return obj;}
	OBJ& operator*() const {return *obj;}
	OBJ* operator->() const {return obj;}
	template<class OBJ1> 
		OBJ1* cast(OBJ1*) const { return dynamic_cast<OBJ1*>(obj); }
	template<class OBJ1> 
		OBJ1* cast() const { return dynamic_cast<OBJ1*>(obj); }
	inline void destroy() {
		if(obj) {
			obj->preDestroy();
			releasePtr(obj);
			obj = NULL;
		}
	}
}; 
typedef Root Interface;
template<class CAST_TYPE> inline CAST_TYPE* clone_ptr(Root* p, Root::CloneMap* clone_map=NULL, Root* clone_obj=NULL) {
	if(p==NULL) return NULL;
	Root* r = p->cloneSmart(clone_map,clone_obj);
	if(r==NULL) return NULL;
	CAST_TYPE* rr = dynamic_cast<CAST_TYPE*>(r);
	if(rr) return rr;
	Ptr<Root> pp=r;
	return NULL;
}
template<class T, class... Args>
[[nodiscard]] Ptr<T> MakePtr(Args&&... args) {
	return Ptr<T>(new T(std::forward<Args>(args)...));
}
#endif 
